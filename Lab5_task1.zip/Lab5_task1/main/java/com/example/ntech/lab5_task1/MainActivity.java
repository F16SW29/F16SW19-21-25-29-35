package com.example.ntech.lab5_task1;

import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener, ScaleGestureDetector.OnScaleGestureListener {
    GestureDetectorCompat gestureDetectorCompat;
    ImageView gesture;
    int count=0;
    int img[] = new int[4];
    private float scale = 1f;
    private float onScaleBegin = 0;
    private float onScaleEnd = 0;
    private ScaleGestureDetector detector;
    String TAG = "DBG";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gesture= findViewById(R.id.imageView2);
        gestureDetectorCompat= new GestureDetectorCompat(this, this);
        img [0]= R.drawable.pic1;
        img [1]= R.drawable.pic2;
        img [2]= R.drawable.pic3;
        img [3]= R.drawable.pic4;
        gesture.setImageResource(img[0]);
        detector= new ScaleGestureDetector(this,this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        gestureDetectorCompat.onTouchEvent(event);
        detector.onTouchEvent(event);
        /*if(event.getPointerCount() > 1){
            int action = event.getAction();
            int index = event.getActionIndex();


               }*/
        return super.onTouchEvent(event);

    }
    @Override public boolean onDown(MotionEvent e) {
         return true; }
    @Override public void onShowPress(MotionEvent e) {

    }
    @Override public boolean onSingleTapUp(MotionEvent e) {
        return true; }
    @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return true; }
    @Override public void onLongPress(MotionEvent e) {
    }
    @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

        float x1= e1.getX();
        float x2= e2.getX();

        if(x1>x2) {
            count++;
            if (count<4){
            gesture.setImageResource(img[count]);
            Toast.makeText(getApplicationContext(), "right swipe", Toast.LENGTH_SHORT).show();
            }
        else{
                Toast.makeText(getApplicationContext(),"no more pictures",Toast.LENGTH_SHORT).show();
            }}
        if (x2>x1){
            count--;
            if (count>0){
            gesture.setImageResource(img[count]);
            Toast.makeText(getApplicationContext(), "left swipe", Toast.LENGTH_SHORT).show();

        }
        else{
                Toast.makeText(getApplicationContext(),"no more pictures",Toast.LENGTH_SHORT).show();
            }}
        return true;}
    @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            return true; }
     @Override
     public boolean onDoubleTap(MotionEvent e) {
        return true; }
     @Override
     public boolean onDoubleTapEvent(MotionEvent e) {
            return true;
    }
    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        scale *= detector.getScaleFactor();
    // Don't let the object get too small or too large.
    scale = Math.max(2.0f, Math.min(scale, 5.0f));
    return true; }
    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        Log.d(TAG, "onScaleBegin");
        onScaleBegin = scale;
    return true; }
    @Override public void onScaleEnd(ScaleGestureDetector detector) {
        Log.d(TAG, "onScaleEnd");
        onScaleEnd = scale;
        if (onScaleEnd > onScaleBegin) {
            Toast.makeText(getApplicationContext(), "Scaled Up by a factor of " +
            String.valueOf(onScaleEnd / onScaleBegin), Toast.LENGTH_SHORT).show();
        }
        if (onScaleEnd < onScaleBegin) {
            Toast.makeText(getApplicationContext(), "Scaled Down by a factor of " +
            String.valueOf(onScaleBegin / onScaleEnd), Toast.LENGTH_SHORT).show(); } }
}

