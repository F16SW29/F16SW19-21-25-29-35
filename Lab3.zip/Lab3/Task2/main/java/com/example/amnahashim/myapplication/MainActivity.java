package com.example.amnahashim.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static java.util.logging.Level.parse;

public class MainActivity extends AppCompatActivity {
    EditText et;
    Button b1,b2,b3,b4,b5,b6,b7;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);
        et = (EditText) findViewById(R.id.editText2);
        b1 = (Button) findViewById(R.id.button);
        b2 =(Button)findViewById(R.id.button2);
        b3 =(Button)findViewById(R.id.button3);
        b4 =(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        b6 =(Button)findViewById(R.id.button6);
        b7 =(Button)findViewById(R.id.button7);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = et.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + text));

//                Intent in= new Intent(MainActivity.this,second.class);
//
                startActivity(i);
            }
            });


              b2.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                     Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                       startActivity(i);
                     // Intent i = new Intent(Intent.ACTION_CAMERA_BUTTON,Uri.parse("content://media/external/images/media/"));
                      //startActivity(i);
                  }
              });

              b3.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse("content://contacts/people/")); startActivity(i);
                  }
              });
            b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse("http://www.google.com/")); startActivity(i);

                }
            });
            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse("content://call_log/calls/1")); startActivity(i);

                }
            });
            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("content://media/external/images/media/")); startActivity(i);

                }
            });
            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String num= et.getText().toString();
                   // Intent i = new Intent(Intent.ACTION_DIAL);
                   // i.setData(Uri.parse("tel:"+num));
                    //startActivity(i);
                    Intent i = new Intent(Intent.ACTION_DIAL); i.setData(Uri.parse("tel:"+num)); startActivity(i);
                }
            });

              }  }
