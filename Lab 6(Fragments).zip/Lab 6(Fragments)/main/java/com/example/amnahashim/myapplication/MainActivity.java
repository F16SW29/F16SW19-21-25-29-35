package com.example.amnahashim.myapplication;

import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements list.ItemSelected {
TextView tv;
  String[]Data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.textView);
       Data =getResources().getStringArray(R.array.Data);
       if(findViewById(R.id.layout_pat)!=null){
           FragmentManager manager=this.getSupportFragmentManager();
           manager.beginTransaction()
                   .hide(manager.findFragmentById(R.id.fragment3))
                   .show(manager.findFragmentById(R.id.fragment2))
                   .commit();
       }
if( findViewById(R.id.layout_pat)!=null){
    FragmentManager manager=this.getSupportFragmentManager();
    manager.beginTransaction()
            .show(manager.findFragmentById(R.id.fragment3))
            .show(manager.findFragmentById(R.id.fragment2))
            .commit();

}
    }

    @Override
    public void onItemSelected(int index) {
        tv.setText(Data[index]);
        if (findViewById(R.id.layout_pat) != null) {
            FragmentManager manager = this.getSupportFragmentManager();
            manager.beginTransaction()
                    .show(manager.findFragmentById(R.id.fragment3))
                    .hide(manager.findFragmentById(R.id.fragment2))
                    .commit();

        }
    }}
