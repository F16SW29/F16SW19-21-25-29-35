package com.example.ntech.lab5_task2;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager;
    Sensor mProxi;
    ImageView imgview;
    float sizeX;
    float sizeY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgview= findViewById(R.id.imageView);
        mSensorManager= (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mProxi= mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        imgview.setImageResource(R.drawable.pic1);
        sizeX=imgview.getScaleX();
        sizeY=imgview.getScaleY();
    }
    @Override
    protected void onResume(){
        super.onResume();
        mSensorManager.registerListener ( this, mProxi, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener( this);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy){
        }
    @Override
    public void onSensorChanged(SensorEvent event) {
        float lux = event.values[0];
       if(event.values[0]<mProxi.getMaximumRange()){
           imgview.setScaleX(sizeX*2);
           imgview.setScaleY(sizeY*2);}
           else{
             imgview.setScaleX(sizeX);
             imgview.setScaleY(sizeY);
             }
        }
}
