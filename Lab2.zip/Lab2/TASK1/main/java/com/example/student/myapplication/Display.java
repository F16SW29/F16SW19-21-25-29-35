package com.example.student.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;


import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class Display extends AppCompatActivity {

    TextView t_user1,t1_email, t1_date;
    ImageView image1;
    String un,email, dob;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        t_user1=findViewById(R.id.t_user);
        t1_email=findViewById(R.id.t_email);
        t1_date=findViewById(R.id.t_Date);
        image1=(ImageView)findViewById(R.id.image1);
        /*Intent in1 = getIntent();
        un= in1.getStringExtra("name");
        t_user1.setText(un);
        email=in1.getStringExtra("Email");
        t1_email.setText(email);
        dob=in1.getStringExtra("Date-Of-Birth");
        t1_date.setText(dob);*/

        }

        /*public void imgChanger(View v){
            image1.setImageResource(R.drawable.image2);
        }*/
        }



